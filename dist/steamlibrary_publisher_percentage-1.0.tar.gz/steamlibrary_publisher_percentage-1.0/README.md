# steamlibrary_publisher-percentage
Python script that tells you the percentage of different publishers in your steam library

Remember to add your API key and steamid (lines 7 and 8)

Get steamid from https://steamdb.info/

Get API key from https://steamcommunity.com/dev/apikey
