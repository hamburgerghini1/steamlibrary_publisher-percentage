# steamlibrary_publisher-percentage
Python script that tells you the percentage of different publishers in your steam library

Remember to add your API key and steamid (lines 7 and 8) Rather fork the repo and add secrets there.

Get steamid from https://steamdb.info/

Get API key from https://steamcommunity.com/dev/apikey

Available from PyPi https://pypi.org/project/steamlibrary-publisher-percentage/1.0/
